import './App.css';
import Home from './components/Home';
import Navbar from './components/Navbar';
import Login from './components/Login';
import Welcome from './components/Welcome';
import { useState } from 'react';

function App() {
  const [session, setSession] = useState(true);
  return (
    <>
      <Navbar />
      <Welcome/>  
      {session === false?<Login/>:''}
      {session === true?<Home/>:''} 
    </>
  );
}

export default App;
