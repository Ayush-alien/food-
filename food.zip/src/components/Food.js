import React, { useState } from 'react'
import './Food.css'

export default function Food({ foodItem }) {
    const [items, setItems] = useState(0); 
    const [cost, setCost] = useState(0); 

    const addItem = (price,id) => {
        setItems(items+1)        
        setCost(price * (items+1)) 
        
    }
    const removeItem = (price,id) => {
        setItems(items-1)        
        setCost(price * (items-1)) 
    }
    return (
        <>
            <div className='foods-item'>
                {
                    foodItem.map((item) => {
                        return (
                            <>
                                <div className='food-card' key={item.id}>
                                    <img src={item.image} alt="" />
                                    <p>{item.name}</p>
                                    <p className='price'>Price {item.price}</p>
                                    {items!=0?<p className='price'>Total {items}</p>:''}
                                    {cost!=0?<p className='price'>Cost (INR):{cost}</p>:''}
                                    <button className='plusBtn' onClick={()=> addItem(item.price,item.id)}> + </button>
                                    <button className='minusBtn' onClick={()=>removeItem(item.price,item.id)}> - </button>
                                </div>

                            </>
                        )
                    })
                }
            </div>
        </>
    )
}
