import React from 'react'
import food from '../item'
import Food from './Food'
export default function Home() {
    return (
    <>
     <Food foodItem={food} />    
    </>
  )
}
