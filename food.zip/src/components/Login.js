import React, { useState } from 'react'
import './Login.css'

export default function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    
    // const data = localStorage.getItem(myObject);
    // const userData = JSON.parse(data);
    // console.log(userData);
  
     const userLogin = () => {
    //   const myObject = {
    //     email: email,
    //     password: password,
    //     session:true
    //   }  
    //   localStorage.setItem(myObject, JSON.stringify(myObject));
    //   alert("Login Successfull.");
     }
    return (
      <>
          <div className='login-div'>
              <p className='Login'>Login</p>
              <label htmlFor="">Email</label>
                <input type="email" value={email} onChange={(e) => { setEmail(e.target.value) }} />        
              <label htmlFor="">Password</label>
                <input type="password" value={password} onChange={(e) => { setPassword(e.target.value) }} />     
              <button onClick={userLogin}>Login</button>
          </div>
      </>
  )
}
