import React from 'react'
import './Navbar.css'

export default function Navbar() {
  return (
      <>
          <nav>
        <i>Food's Resturant</i>
        <img src='Images/cart.svg' alt="Cart" />
          </nav>
   </>
  )
}
