import React, { useState } from 'react'
import './Welcome.css'
export default function Welcome() {
  const [nextPage, setNextPage] = useState(false);
  return (
    <>
      
      <p className='welcome-heading'>Welcome to Food's Kitchen</p>
       <button className='go-to-menu-btn' onClick={(nextPage)=>{setNextPage(true)}}> Go To Menu </button>
    </>
  )
}

