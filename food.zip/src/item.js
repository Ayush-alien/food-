 const food = [
    {
        id: 1,
        name: "Hamburger",
        price: 200,
        image:"images/Burger.jpeg",
    },
    {
        id: 2,
        name: "Fries",
        price: 100,
        image:"images/Fries.jpeg",
    },
    {
        id: 3,
        name: "Coke",
        price: 50,
        image:"images/Coke.jpeg", 
    },
    {
        id: 4,
        name: "Pepsi",
        price: 50,
        image:"images/Pepsi.jpeg", 
    }
]
export default food;
